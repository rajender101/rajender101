package main_pack;
import pack1.*;
import pack2.*;

public class Main_funtion {
	
	public static void main(String[] args) {
		double pack1_answer,pack2_answer;
//		Arithmetic obj1 = new Arithmetic();
//		pack_answer =obj1.add();
//		System.out.println(pack_answer);
		CondOperator obj2 = new CondOperator();
		System.out.println(obj2.cond_greater_2val(3, 1)) ;
		
		
	}

}
