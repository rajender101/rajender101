package pack1;

public class Assignment {
	int b;
	public int assignInt(int a) {
		return b =a;
	}
}
