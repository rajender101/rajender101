package pack1;

import java.util.Scanner;

public class Arithmetic {
	double num1,num2,answer;
	Scanner sc = new Scanner(System.in);
	public double add() {
		System.out.println("Enter first number");
		num1 = sc.nextInt();
		System.out.println("Enter 2nd number");
		num2 = sc.nextInt();
		return answer = num1+ num2;
	}
	public double subtract() {
		System.out.println("Enter first number");
		num1 = sc.nextInt();
		System.out.println("Enter 2nd number");
		num2 = sc.nextInt();
		return answer = num1- num2;
	}
	public double multiply() {
		System.out.println("Enter first number");
		num1 = sc.nextInt();
		System.out.println("Enter 2nd number");
		num2 = sc.nextInt();
		return answer = num1* num2;
	}
	public double division() {
		System.out.println("Enter first number");
		num1 = sc.nextInt();
		System.out.println("Enter 2nd number");
		num2 = sc.nextInt();
		return answer = num1/ num2;
	}
	public double mod() {
		System.out.println("Enter first number");
		num1 = sc.nextInt();
		System.out.println("Enter 2nd number");
		num2 = sc.nextInt();
		return answer = num1% num2;
	}
}
