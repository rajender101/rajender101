package pack2;

public class CondOperator {
	int max;
	public int cond_greater_2val(int a,int b) {
		return max = (a>b)? a:b;
	}
	

}
